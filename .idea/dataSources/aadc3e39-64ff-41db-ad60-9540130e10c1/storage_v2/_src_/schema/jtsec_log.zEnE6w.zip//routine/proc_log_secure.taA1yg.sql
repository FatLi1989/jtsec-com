create procedure proc_log_secure(IN ads int, IN t_name varchar(225))
  comment '日志数据阀值或是临界值监控的实现函数'
  BEGIN
	-- [v1.0.2] by lioncode at 2017-11-05 15:00 
	-- 负责根据日志策略，对日志表进行监测，生成阈值告警日志，或执行日志回滚/备份操作，并生成相应的日志。

	DECLARE high INT;  -- 临界阈值
	DECLARE low_limit int; -- 告警阈值
	DECLARE cnt INT; -- 当前总条数
	DECLARE rb_cnt INT;  -- 回滚数量
	DECLARE limit_type CHAR;  -- 阈值策略类型
	DECLARE scure_type CHAR;  -- 安全策略类型
	DECLARE exe_flag INT;  -- 执行标识
	DECLARE last_warn_time date; -- 最新的日志临界告警记录时间
	DECLARE last_rollback_time date; -- 最新的日志回滚告警记录时间
	DECLARE last_backup_time date; -- 最新的日志备份告警记录时间
	DECLARE last_warnlog_sid CHAR;		-- 最新日志临界告警记录的唯一标识号（组号）
	DECLARE	backup_table_name CHAR;

	-- 执行标识预设为0，表示不执行
	SET exe_flag = 0;
	
	
	-- 获取临界阈值highLimit
	SET @sql_tmp = CONCAT("SET @high = (select high_limit from jtsec_com.logconfig where table_name = '",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 获取告警阈值low_limit
	SET @sql_tmp = CONCAT("SET @low_limit = (select low_limit from jtsec_com.logconfig where table_name ='",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 获取当前数据条数
	SET @sql_tmp = CONCAT("SET @cnt = (select count(*) from ",t_name,");");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	-- 获取回滚数量rollback_count
	SET @sql_tmp = CONCAT("SET @rb_cnt = (select rollback_count from jtsec_com.logconfig where table_name ='",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 获取阈值策略limit_type。如果limit_type=1，代表按数据条数(条)进行策略控制；如果limit_type=2，代表按磁盘空间(%)进行策略控制。
	SET @sql_tmp = CONCAT("SET @limit_type = (select limit_type from jtsec_com.logconfig where table_name ='",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	-- 获取安全策略scure_type。如果scure_type=1，代表备份；如果scure_type=2，代表回滚。
	SET @sql_tmp = CONCAT("SET @scure_type =(select scure_type from jtsec_com.logconfig where table_name = '",t_name,"')");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;


	-- 如果阀值策略limit_type=1，代表策略为“数据条数(条)”，按照数据条数进行阈值设定。
	IF('1' = @limit_type) THEN
		-- 如果当前数据条数大于告警阈值low_limit，且小于临界阈值highLimit。
		IF(@cnt > @low_limit AND @cnt < @high) THEN
			-- 当数据条数处于超过告警阈值的状态时，如果不进行必要的逻辑判断，会造成每次执行告警阈值判断后都会产生一条告警日志，直至到达日志设定最高临界阈值上限。
			-- 为避免告警日志的反复产生，进行了下面的逻辑判断，来避免反复产生同样的临界告警日志。
			-- 实现逻辑：当发现日志条数大于告警阈值，并小于最高临界阈值上限时，会进入到该代码块中，然后进行如下逻辑判断，确认是否需要产生一条新的告警日志。
			-- 1.查询存储告警记录日志表中，该日志表的最后（最新）的一条告警日志的时间及该条日志的组号
			-- 2.然后判断安全策略是什么，根据安全策略的不同，使用上面的组号作为其中的一个必要查询条件，查询是否存在对应的一条回滚/备份日志
			-- 3.如果不存在，则证明告警后，还一直没有发生回滚/备份事件，则不需要再次记录临界告警日志，
			--   若存在，则证明告警之后，发生过至少一次回滚/备份时间，则应该记录这次的告警日志。
			SET @do_record_flag = TRUE;
			-- 查询该日志表最新一条告警日志的时间。
			SET @sql_tmp = CONCAT("SET @last_warn_time =(select max(ReceivedAt) from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '1' ORDER BY ReceivedAt DESC)");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
			-- CALL debug_call("当前数据条数", @cnt, "告警阈值及临界阈值", @low_limit, @high, @result);
			-- 说明至少存在一条告警日志，则根据安全策略类型（回滚/备份），继续判断是否存在与该条告警日志同属一组的回滚或备份日志。
			IF (@last_warn_time is not null) THEN
				-- 使用最新一条告警日志的时间，条件查询该日志表最新一条告警日志的组号。
				SET @sql_tmp = CONCAT("SET @last_warnlog_sid =(select host from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '1' AND ReceivedAt = '",@last_warn_time,"' ORDER BY ReceivedAt DESC)");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				-- 如果安全策略scure_type值为2，代表策略为回滚
				IF ('2' = @scure_type) THEN	
					-- 使用组号，条件查询该日志表最后一条回滚告警日志的时间。
					SET @sql_tmp = CONCAT("SET @last_rollback_time =(select max(ReceivedAt) from jtsec_com.log_warning where table_name = '",t_name,"' AND event = 3 AND host = '",@last_warnlog_sid,"' ORDER BY ReceivedAt DESC)");
					PREPARE pre_sql FROM @sql_tmp;
					EXECUTE pre_sql;
					-- CALL debug_call("安全策略为回滚","最新回滚日志时间", @last_rollback_time, "最新告警日志时间", @last_warn_time, @result);
					-- 没有查到与该条告警日志一组的回滚日志，说明该条告警后，还未发生过回滚事件，则不需要（反复）再记录告警日志
					IF (@last_rollback_time is null) THEN
						SET @do_record_flag = FALSE;
					END IF;
				-- 如果安全策略scure_type值为1，代表策略为备份
				ELSE
					-- 使用组号，查询该日志表最后一条备份告警日志的时间。
					SET @sql_tmp = CONCAT("SET @last_backup_time =(select max(ReceivedAt) from jtsec_com.log_warning where table_name = '",t_name,"' AND event = 4 AND host = '",@last_warnlog_sid,"' ORDER BY ReceivedAt DESC)");
					PREPARE pre_sql FROM @sql_tmp;
					EXECUTE pre_sql;
					-- CALL debug_call("安全策略为备份","最新备份日志时间", @last_backup_time, "最新告警日志时间", @last_warn_time, @result);
					-- 没有查到与该条告警日志一组的备份日志，说明该条告警后，还未发生过备份事件，则不需要（反复）再记录告警日志
					IF (@last_backup_time is null) THEN
						SET @do_record_flag = FALSE;
					END IF;
				END IF;
			END IF;
			IF @do_record_flag THEN
				-- 产生告警日志，并记录。
				SET @sql_tmp = CONCAT("INSERT INTO jtsec_com.log_warning(ReceivedAt,event,table_name,host,pro_name,msg) values((select now()), 1,'",t_name ,"','",UNIX_TIMESTAMP(),"', '0', concat('日志阈值告警，距离数据库临界值还剩 [<font size=\"2\" color=\"red\">', ", @high-@cnt , " ,'</font>]条。告警阈值', ", @low_limit, ", '，临界阈值', ", @high, ", '，当前值', ", @cnt, ", '。'))");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql; 
			END IF;

		-- 如果当前数据条数大于临界阈值highLimit，则将执行标志置为1，表示真。
		ELSEIF(@cnt >= @high) THEN
			SET exe_flag = 1;
		END IF;
		
	-- 如果阀值策略limit_type=2，代表策略为“磁盘空间(%)”，按照磁盘空间进行阈值设定。
	ELSE
		-- 如果ads（磁盘剩余有效空间）值大于0
		IF(ads > 0) THEN
			IF(ads < @low_limit AND ads > @high) THEN
				SET @sql_tmp = CONCAT("INSERT INTO jtsec_com.log_warning(ReceivedAt,event,table_name,host,pro_name,msg) values((select now()), 2,'",t_name ,"','",UNIX_TIMESTAMP(),"', '0', concat('日志存储告警，磁盘空间距离临界值剩余 [<font size=\"2\" color=\"red\">', ", ads-@high, " ,'%</font>].'))");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF(ads <= @high) THEN
				SET exe_flag = 1;
			END IF;
		-- 如果ads（磁盘剩余有效空间）值小于等于0
		ELSE
			-- 判断日志表数据总条数是否大于等于50w，如果是执行标识置为1真。
			IF(@cnt >= 500000) THEN
				SET exe_flag = 1;
			END IF;
		END IF;
		
	END IF;
	
	-- 执行回滚/备份操作
	IF (1 = exe_flag) THEN
		-- 首先，查询该日志表最新一条告警日志的时间及其日志组号。
		-- 查询该日志表最新一条告警日志的时间。
		SET @sql_tmp = CONCAT("SET @last_warn_time =(select max(ReceivedAt) from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '1' ORDER BY ReceivedAt DESC)");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
		-- 然后获取刚刚取得的最新告警日志的组号
		IF (@last_warn_time is not null) THEN
			-- 使用最新一条告警日志的时间，条件查询该日志表最新一条告警日志的组号。
			SET @sql_tmp = CONCAT("SET @last_warnlog_sid =(select host from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '1' AND ReceivedAt = '",@last_warn_time,"' ORDER BY ReceivedAt DESC)");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
			-- CALL debug_call("触发回滚或备份","最新告警日志时间", @last_warn_time, "最新告警日志组号", @last_warnlog_sid, @result);
		END IF;

		-- 如果安全策略scure_type值为2，代表策略为回滚
		IF ('2' = @scure_type) THEN	
			SET @sql_tmp = CONCAT("delete from ",t_name," order by ID asc limit ?");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql USING @rb_cnt;
			
			-- @last_warnlog_sid不为null代表找到了最新告警日志
			IF (@last_warnlog_sid is not null) THEN
				-- 使用最新告警日志的组号，条件查询是否存在与之对应的回滚日志，获取其时间。
				SET @sql_tmp = CONCAT("SET @last_rollback_time =(select ReceivedAt from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '3' AND  host= '",@last_warnlog_sid,"' ORDER BY ReceivedAt DESC)");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;	
			END IF;
			
			-- 若没有找到告警日志（@last_warnlog_sid为null时），或找到告警日志（@last_warnlog_sid不为null时），
			-- 如果找到了告警日志，也找到了对应的回滚日志（@last_rollback_time有值表示存在对应回滚日志），则取系统时间戳作为这次要产生的回滚日志的组号
			-- 如果找到了告警日志，但没找到与告警日志对应的备份日志，说明告警之后没有发生备份事件，则以告警日志的组号作为备份日志的组号，则@last_warnlog_sid值不需要调整。
			IF (@last_warnlog_sid is null OR @last_rollback_time is not null) THEN
				SET @last_warnlog_sid = UNIX_TIMESTAMP();
			END IF;

			-- CALL debug_call("执行回滚操作","与最新告警日志同组的回滚日志时间", @last_rollback_time, "此次回滚日志组号", @last_warnlog_sid, @result);

			SET @sql_tmp = CONCAT("INSERT INTO jtsec_com.log_warning(ReceivedAt,event,table_name,host,pro_name,msg) values((select now()), 3,'",t_name ,"','",@last_warnlog_sid, "', '0', concat('日志回滚告警，日志数量已达临界值', ", @high, ", '条，当前条数为', ", @cnt , ",'。自动[<font size=\"2\" color=\"red\">回滚数据</font>]', ", @rb_cnt, " ,'条。'));");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
		-- 如果安全策略scure_type值为1，代表策略为备份
		ELSE
			SET @backup_table_name = CONCAT(t_name,"_",UNIX_TIMESTAMP());
			SET @sql_tmp = CONCAT("Alter TABLE ",t_name," RENAME TO ",@backup_table_name);
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;

			IF (t_name = 'log_http_msg') THEN
				SET @sql_tmp = CONCAT("CREATE TABLE log_http_msg (  ID int(10) unsigned NOT NULL AUTO_INCREMENT,  ReceivedAt datetime DEFAULT NULL,  SysLogTag varchar(60) DEFAULT NULL,  user varchar(60) DEFAULT NULL,  ip varchar(60) DEFAULT NULL,  action varchar(225) DEFAULT NULL,  result varchar(60) DEFAULT NULL,  flag varchar(60) DEFAULT NULL,  PRIMARY KEY (ID)) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
			ELSEIF (t_name = 'log_ftp_msg') THEN
				SET @sql_tmp = CONCAT("CREATE TABLE log_ftp_msg (ID int(10) unsigned NOT NULL AUTO_INCREMENT, ReceivedAt datetime DEFAULT NULL, FromHostIP varchar(60) DEFAULT NULL, Message BLOB, SyslogTag varchar(60) DEFAULT NULL, flag varchar(60) DEFAULT NULL, PRIMARY KEY (ID)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
			ELSEIF (t_name = 'log_sfts_msg') THEN
				SET @sql_tmp = CONCAT("CREATE TABLE log_sfts_msg (  ID int(10) unsigned NOT NULL AUTO_INCREMENT,  ReceivedAt datetime DEFAULT NULL,  FromHostIP varchar(60) DEFAULT NULL,  Message blob,  SyslogTag varchar(60) DEFAULT NULL,  flag varchar(60) DEFAULT NULL,  PRIMARY KEY (ID)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;");
			ELSEIF (t_name = 'log_video_msg' OR t_name = 'log_gstmedia_msg') THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, " LIKE log_template_1");
			ELSEIF (t_name = 'audit_log' OR t_name = 'oper_log' OR t_name = 'os_log' OR t_name = 'filter_log' OR t_name = 'http_proxy_log' OR t_name = 'https_proxy_log' OR t_name = 'smtp_proxy_log' OR t_name = 'pop_proxy_log' OR t_name = 'ftp_proxy_log') THEN
			SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, " LIKE serv_log_template");
			ELSE				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, " LIKE ", "template_", t_name);
			END IF;
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
			
			-- @last_warnlog_sid值不为null，代表找到了最新告警日志
			IF (@last_warnlog_sid is not null) THEN
				-- 使用最新一条告警日志的组号，条件查询该日志表是否存在与之对应的备份日志，获取其时间。
				SET @sql_tmp = CONCAT("SET @last_rollback_time =(select ReceivedAt from jtsec_com.log_warning where table_name = '",t_name,"' AND event = '4' AND  host= '",@last_warnlog_sid,"' ORDER BY ReceivedAt DESC)");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				-- 如果找到了与告警日志对应的备份日志（@last_rollback_time不为null说明有对应的备份日志），则取系统时间戳作为这次要产生的备份日志的组号。
				-- 如果没找到与告警日志对应的备份日志，说明告警之后没有发生备份事件，以告警日志的组号作为备份日志的组号，则@last_warnlog_sid值不需要调整。
				IF (@last_rollback_time is not null) THEN
					SET @last_warnlog_sid = UNIX_TIMESTAMP();
				END IF;
			ELSE
				-- 如果没有找到告警日志，则取系统时间戳作为这次要产生的备份日志的组号
				SET @last_warnlog_sid = UNIX_TIMESTAMP();
			END IF;

			-- CALL debug_call("执行备份操作","上一次备份日志时间", @last_rollback_time, "此次备份日志组号", @last_warnlog_sid, @result);

			SET @sql_tmp = CONCAT("INSERT INTO jtsec_com.log_warning(ReceivedAt,event,table_name,host,pro_name,msg) values((select now()), 4, '",t_name ,"', '",@last_warnlog_sid ,"' , '0', concat('日志备份告警，日志数量已达临界值', ", @high, " , '条，当前条数为', ", @cnt, ",'条。自动[<font size=\"2\" color=\"red\">备份数据表</font>]，主表已备份为：', '", @backup_table_name, "', '。'));");
			-- CALL debug_call("执行的SQL", @sql_tmp , NULL, NULL, NULL, @result);
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;

		END IF;
	END IF;

END;

