create procedure proc_auto_rollback_bak_table(IN ads int)
  comment '用于对jtsec_log库中日志数据表做备份回滚操作'
  BEGIN
	DECLARE high INT DEFAULT 0;
	DECLARE low_limit int DEFAULT 0;
	DECLARE cnt INT;
	DECLARE rb_cnt INT;
	DECLARE limit_type CHAR;
	DECLARE scure_type CHAR;
	DECLARE exe_flag INT;

	DECLARE t_name_var VARCHAR(225);
	DECLARE t_name_var_1 VARCHAR(225);
	DECLARE tmp TEXT  DEFAULT '';
	
	DECLARE cur_end, cur_end_1 INT DEFAULT FALSE;
	

	DECLARE cur CURSOR FOR SELECT table_name from log_config;  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_end = TRUE;
	

	OPEN cur;
		read_loop: LOOP
			FETCH cur INTO t_name_var;
			IF cur_end THEN
				LEAVE read_loop;
			END IF;

			SET @sql_tmp = CONCAT("SET @high = (select high_limit from log_config where table_name = '",t_name_var,"');");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
			
			
			SET @sql_tmp = CONCAT("SET @low_limit = (select low_limit from log_config where table_name = '",t_name_var,"');");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
					
			SET @sql_tmp = CONCAT("SET @rb_cnt = (select rollback_count from log_config where table_name ='",t_name_var,"');");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
			
			SET @sql_tmp = CONCAT("SET @limit_type = (select limit_type from log_config where table_name ='",t_name_var,"');");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;

			
			SET @sql_tmp = CONCAT("SET @scure_type =(select scure_type from log_config where table_name = '",t_name_var,"')");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;

			
			IN_CUR:BEGIN
				
				DECLARE cur_1 CURSOR FOR SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_NAME LIKE CONCAT('%',t_name_var) ORDER BY TABLE_NAME DESC ;
				DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_end_1 = TRUE;
				
				OPEN cur_1;
					read_loop_1: LOOP
						SET exe_flag = 0;
						FETCH cur_1 INTO t_name_var_1;
						IF cur_end_1 THEN
							LEAVE read_loop_1;
						END IF;
						
						
						SET @sql_tmp = CONCAT("SET @cnt = (select count(*) from ",t_name_var_1,");");
						PREPARE pre_sql FROM @sql_tmp;
						EXECUTE pre_sql;

						IF('1' = @limit_type) THEN
							IF(@cnt > @low_limit AND @cnt < @high) THEN
								SET @sql_tmp = CONCAT("INSERT INTO log_warning values(id,(select now()), 1,'",t_name_var_1 ,"','localhost', 'mysql', concat('日志告警,距离数据库临界值还剩 [<font size=\"2\" color=\"red\">', ",@high-@cnt,",'</font>]条.'))");
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql;
							ELSEIF(@cnt >= @high) THEN
								SET exe_flag = 1;
							END IF;

						ELSE	
							IF(ads > 0) THEN
								IF(ads < @low_limit AND ads > @high) THEN
									SET @sql_tmp = CONCAT("INSERT INTO log_warning values(id,(select now()), 2,'",t_name_var_1 ,"','localhost', 'mysql', concat('日志告警,磁盘空间距离临界值剩余 [<font size=\"2\" color=\"red\">', ",ads-@high,",'%</font>].'))");
									PREPARE pre_sql FROM @sql_tmp;
									EXECUTE pre_sql;
								ELSEIF(ads <= @high) THEN
									SET exe_flag = 1;
								END IF;
							ELSE
								IF(@cnt >= 500000) THEN
									SET exe_flag = 1;
								END IF;
							END IF;
							
						END IF;
									
						IF (1 = exe_flag) THEN
							IF ('2' = @scure_type) THEN	
								SET @sql_tmp = CONCAT("delete from ",t_name_var_1," order by ID asc limit ?");
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql USING @rb_cnt;
								
								SET @sql_tmp = CONCAT("INSERT INTO log_warning values(id,(select now()), 3,'",t_name_var_1 ,"','localhost', 'mysql', concat('日志告警,日志数量已达临界值[<font size=\"2\" color=\"red\">回滚数据</font>]', @rb_cnt,'条.'));");
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql;

							ELSE			
								SET @sql_tmp = CONCAT("Alter TABLE ",t_name_var_1," RENAME TO ",t_name_var_1,"_",UNIX_TIMESTAMP());
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql;

								SET @sql_tmp = CONCAT("CREATE TABLE ",t_name_var_1," LIKE log_template");
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql;
								
								SET @sql_tmp = CONCAT("INSERT INTO log_warning values(id,(select now()), 4,'",t_name_var_1 ,"','localhost', 'mysql', concat('日志告警,日志数量已达临界值[<font size=\"2\" color=\"red\">备份数据表</font>].'));");
								PREPARE pre_sql FROM @sql_tmp;
								EXECUTE pre_sql;
							END IF;
						END IF;

						
					END LOOP;
				CLOSE cur_1;
				SET cur_end_1 = FALSE;
			END IN_CUR;
			
		END LOOP;	
	CLOSE cur;
	
END;

