create procedure call_log_secure()
  comment '日志安全设置函数
通过事件定时（默认每小时运行一次）调用此函数，用来调用日志备份或回滚的存储过程，完成日志存储的安全保障。'
  BEGIN
	-- 该函数作用为：定义哪些表需要定时进行日志存储的安全保障操作，即针对这些表调用用来进行日志备份或回滚的存储过程。

	-- 执行log_http_msg（安全文件传输日志表）日志表的备份或回滚操作
	CALL proc_log_secure(0, 'log_http_msg');
	CALL proc_log_secure(0, 'log_ftp_msg');
	CALL proc_log_secure(0, 'log_sfts_msg');
	CALL proc_log_secure(0, 'log_video_msg');
	CALL proc_log_secure(0, 'log_gstmedia_msg');
	CALL proc_log_secure(0, 'log_lbproxy_msg');
	CALL proc_log_secure(0, 'log_httpproxy_msg');
	CALL proc_log_secure(0, 'syn_flood_log');
	CALL proc_log_secure(0, 'icmp_flood_log');
	CALL proc_log_secure(0, 'udp_flood_log');
		
	-- 双向网闸日志安全策略控制任务
	CALL proc_log_secure(0, 'tw_audit_log');	-- 双向网闸审计日志
	CALL proc_log_secure(0, 'tw_oper_log');	-- 双向网闸操作日志
	CALL proc_log_secure(0, 'tw_os_log');	-- 双向网闸系统日志
	CALL proc_log_secure(0, 'tw_serv_log');	-- 双向网闸服务日志
	CALL proc_log_secure(0, 'tw_filter_log');	-- 双向网闸非法阻断日志
	
	-- 新双向网闸v2服务日志安全策略控制任务
	CALL proc_log_secure(0, 'audit_log');	-- 审计日志
	CALL proc_log_secure(0, 'oper_log');	-- 操作日志
	CALL proc_log_secure(0, 'os_log');		-- 系统日志
	CALL proc_log_secure(0, 'filter_log');	-- 非法拦截日志
	CALL proc_log_secure(0, 'http_proxy_log');	-- http服务日志
	CALL proc_log_secure(0, 'https_proxy_log');	-- https操作日志
	CALL proc_log_secure(0, 'smtp_proxy_log');	-- smtp系统日志
	CALL proc_log_secure(0, 'pop_proxy_log');	-- pop服务日志
	CALL proc_log_secure(0, 'ftp_proxy_log');	-- ftp服务日志

  	-- CALL proc_log_bak_rollback(0, 'log_http_msg');
	-- CALL proc_log_bak_rollback(0, 'log_ftp_msg');
	-- CALL proc_log_bak_rollback(0, 'log_sfts_msg');
	-- CALL proc_log_bak_rollback(0, 'log_video_msg');
	-- CALL proc_log_bak_rollback(0, 'log_gstmedia_msg');
	-- CALL proc_log_bak_rollback(0, 'log_lbproxy_msg');
  	-- CALL proc_log_bak_rollback(0, 'log_httpproxy_msg');
  	-- CALL proc_log_bak_rollback(0, 'syn_flood_log');
  	-- CALL proc_log_bak_rollback(0, 'icmp_flood_log');

END;

