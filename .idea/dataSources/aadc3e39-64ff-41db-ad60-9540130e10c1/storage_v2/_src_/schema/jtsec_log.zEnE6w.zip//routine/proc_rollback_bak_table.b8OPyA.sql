create procedure proc_rollback_bak_table(IN t_name varchar(100), IN rollback_count int)
  BEGIN
	IF ( rollback_count > 0)
	THEN
		SET @sql_tmp = CONCAT("DELETE FROM ", t_name, " ORDER BY ReceivedAt ASC LIMIT ", rollback_count);
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	ELSE
		
		SET @sql_tmp = CONCAT("ALTER TABLE ", t_name, " RENAME TO ", t_name, "_", UNIX_TIMESTAMP());
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, " LIKE log_template;");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	END IF;

END;

