create procedure proc_bak_log_clear(IN t_name varchar(225))
  comment '当备份表超过一定数量时，主动删除早期备份的表'
  BEGIN
  -- [v101] 该版本从备份表名截取出主表名称时，规则为计算出最后一个下划线（_）及之后的字符长度，然后节去掉得到的就是主表名。
  -- 该存储过程的作用为：清理给定日志表对应的自动生成的备份表，根据预设的对这类表的清理策略，控制当备份表超过一定数量时，主动删除早期备份的表。
  -- 系统通过定时事件event_clear_baklog（清除备份日志），调用call_log_clear（备份日志清除函数），在该函数中会对指定表执行该存储过程。

	-- 参数t_name，是需要进行备份表清理的日志表的主表名，例如log_sfts_msg这个表，要进行它的备份表（表名如log_sfts_msg_1480667144形式的）清理工作
	-- 备份表总数
	DECLARE total_tables INT;
	-- 游标循环时备份表名称
  	DECLARE t_name_var VARCHAR(225);
  	-- 游标结束标识位，默认为false
	DECLARE cur_end INT DEFAULT FALSE;
  	-- 当前游标位，第几行数据
	DECLARE counter INT DEFAULT 0;
  	-- 临时变量，用来存储对备份表表名进行逻辑处理后的临时表名
	DECLARE t_name_tmp TEXT  DEFAULT '';

  	-- 查询所有包含t_name名称的表，包括主表与备份表，将表名集合存入游标cur
 	DECLARE cur CURSOR FOR select TABLE_NAME from information_schema.tables where `TABLE_SCHEMA`='jtsec_log' AND table_name LIKE CONCAT(t_name,"_%") AND table_name NOT IN (select col1 from tmp_cache_tab) ORDER BY TABLE_NAME ASC ;

  	-- 进行游标属性声明设置，在游标循环到最后会将 cur_end 设置为 1
  	DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_end = TRUE;

	-- 统计日志表的数量（包括主表与备份表）
	SET @sql_tmp = CONCAT("SET @total_tables =(select count(TABLE_NAME) as tab_cnt from `INFORMATION_SCHEMA`.`TABLES` where `TABLE_SCHEMA`='jtsec_log' and `TABLE_NAME` LIKE '",t_name,"_%' AND table_name NOT IN (select col1 from tmp_cache_tab));");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	-- 最大备份表数量
	SET @sql_tmp = CONCAT("SET @bak_tab_max = (select bak_tab_max from jtsec_com.logconfig where table_name = '",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	-- 如果日志表数量超过bak_tab_max（默认是5）个
	IF(@total_tables > @bak_tab_max) THEN
    -- 打开游标
		OPEN cur;
    -- 循环游标集合中的每一行
		read_loop: LOOP
			-- 将本行中的表名存入t_name_var变量，类似log_sfts_msg_1480667144
			FETCH cur INTO t_name_var;
			-- 如果游标结束标识位cur_end为真，或者当前游标行数counter值大于等于备份表总数量减5，则不再进行备份表删除，即最少还会保留bak_tab_max张备份表（默认是5张）
			IF ( cur_end OR counter>=(@total_tables-@bak_tab_max) )THEN
				-- 调试日志
				-- SET @debug_tmp =  CONCAT("insert INTO `debug_tab` (`col1`, `col2`, `col3`, `col4`, `col5`) values ('", '--LEAVE LOOP--' ,"','", t_name ,"','", t_name_var ,"','", counter ,"','", cur_end ,"');");
				-- PREPARE debug_sql FROM @debug_tmp;
				-- EXECUTE debug_sql;
				-- 结束游标循环（关键字LEAVE像其他语言中的break会离开LOOP指定的块）
				LEAVE read_loop;
			END IF;
			-- 对临时变量t_name_tmp赋值，值为从游标当前行t_name_var值中，截取最后一个 '_' 之前的所有字符，例如log_sfts_msg_1480667144截取后为log_sfts_msg		
			-- SET t_name_tmp = substring_index(t_name_var, '_', 3);
			-- 从最左侧开始截取表名，截取的长度为表名长度减去最后一个分割符（含）之后的长度
			SET t_name_tmp = LEFT(t_name_var, LENGTH(t_name_var)-LOCATE('_',REVERSE(t_name_var)));
			-- 调试日志
			-- SET @debug_tmp =  CONCAT("insert INTO `debug_tab` (`col1`, `col2`, `col3`, `col4`, `col5`) values ('", 'Find bak tab' ,"','", t_name_var ,"','", t_name_tmp ,"','", counter ,"','", @total_tables ,"');");
			-- PREPARE debug_sql FROM @debug_tmp;
			-- EXECUTE debug_sql;
			
      -- 如果备份表名截取后的名称与主表名称相同，执行该备份表删除操作
			IF (t_name_tmp = t_name ) THEN
				SET @sql_tmp = CONCAT("DROP TABLE ",t_name_var);
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				-- 调试日志
				-- SET @debug_tmp =  CONCAT("insert INTO `debug_tab` (`col1`, `col2`, `col3`, `col4`, `col5`) values ('", 'Del bak tab' ,"','", t_name_var ,"','", t_name_tmp ,"','", counter ,"','", @total_tables ,"');");
				-- PREPARE debug_sql FROM @debug_tmp;
				-- EXECUTE debug_sql;
				-- 当前游标位加1，表示已循环读取了一行
				SET counter = counter+1;
			END IF;
    -- 结束游标循环
		END LOOP;
    -- 关闭游标
		CLOSE cur;
	END IF;
END;

