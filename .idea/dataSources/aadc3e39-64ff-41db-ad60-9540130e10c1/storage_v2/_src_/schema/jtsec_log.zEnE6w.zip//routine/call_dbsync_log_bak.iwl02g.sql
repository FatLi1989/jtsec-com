create procedure call_dbsync_log_bak()
  comment '定时器调用此函数实现数据库同步日志备份监测'
  BEGIN
	CALL pro_dbsync_log_bak('dbsync_extract_log');
	CALL pro_dbsync_log_bak('dbsync_load_log');
	CALL pro_dbsync_log_bak('dbsync_extract_stats_min');
	CALL pro_dbsync_log_bak('dbsync_load_stats_min');
END;

