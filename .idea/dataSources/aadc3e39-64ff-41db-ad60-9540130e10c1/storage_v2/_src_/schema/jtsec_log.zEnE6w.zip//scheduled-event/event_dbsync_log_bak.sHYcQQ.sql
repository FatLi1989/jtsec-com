create definer = root@`%` event event_dbsync_log_bak
  on schedule
    every '1' DAY
      starts '2017-03-15 00:00:00'
  enable
do
  CALL call_dbsync_log_bak();

