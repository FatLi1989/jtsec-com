create definer = root@`%` event event_clear_baklog
  on schedule
    every '1' DAY
      starts '2011-07-29 00:00:00'
  enable
do
  -- 清理备份日志事件
-- 用途：用来定时检测日志备份表情况，根据每个日志表配置的策略，清理自动生成的或人工导入的日志备份表，默认每天零点执行一次。
CALL call_log_clear();

