create procedure proc_create_dev_log_table(IN t_name            varchar(100), IN log_type varchar(20),
                                           IN dev_syslog_gather varchar(20))
  BEGIN
	
	DECLARE total_tables INT;
	
	
	SET @sql_tmp = CONCAT("SET @total_tables =(SELECT COUNT(TABLE_NAME) AS tab_cnt FROM `INFORMATION_SCHEMA`.`TABLES` WHERE `INFORMATION_SCHEMA`.`TABLES`.TABLE_SCHEMA = 'jtsec_com' AND`TABLE_NAME` = '",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	IF (@total_tables = 0)
	THEN
		IF(dev_syslog_gather = '1')
		THEN
			IF (log_type = '000200001' OR log_type = '000200002')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_audit_log"," LIKE template_tw_audit_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_oper_log"," LIKE template_tw_oper_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_os_log"," LIKE template_tw_os_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_serv_log"," LIKE template_tw_serv_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_filter_log"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF (log_type = '000100001' OR log_type = '000100002')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_http_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_sfts_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_ftp_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_icmp_flood_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_syn_flood_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;

				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_sfts_log_history"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_count_log"," LIKE log_count_sfts_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF (log_type = '000400001' OR log_type = '000400002' OR log_type = '000400003')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_http_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_video_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF (log_type = '000300001' OR log_type = '000300002')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_sfts_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_http_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_sfts_log_history"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_count_log"," LIKE log_count_sfts_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF (log_type = '000900001')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_fw_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			ELSEIF (log_type = '001000001')	
			THEN
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_ips_log"," LIKE log_template;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_log_os"," LIKE template_tw_filter_log;");
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
			END IF;	
		END IF;	
		    SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_dev_cpu_info"," LIKE template_dev_cpu_info;");
		    PREPARE pre_sql FROM @sql_tmp;
		    EXECUTE pre_sql;
		
		    SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_dev_mem_info"," LIKE template_dev_mem_info;");
		    PREPARE pre_sql FROM @sql_tmp;
		    EXECUTE pre_sql;

			SET @sql_tmp = CONCAT("CREATE TABLE ", t_name, "_other_log"," LIKE log_template;");
			PREPARE pre_sql FROM @sql_tmp;
			EXECUTE pre_sql;
		
		
	END IF;
END;

