create procedure proc_log_backup(IN t_name varchar(255), IN time_stamp varchar(255))
  BEGIN
	SET @sql_tmp = CONCAT("Alter TABLE ",t_name," RENAME TO ",t_name,"_",time_stamp);
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	SET @sql_tmp = CONCAT("CREATE TABLE ",t_name," LIKE ",t_name,"_",time_stamp);
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
END;

