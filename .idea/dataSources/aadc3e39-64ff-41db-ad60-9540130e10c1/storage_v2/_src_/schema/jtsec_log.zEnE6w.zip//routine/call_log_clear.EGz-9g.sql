create procedure call_log_clear()
  comment '清除备份日志函数
通过事件定时（默认每天零点运行一次）调用此函数，用来清理（自动生成/人工导入）日志备份表。'
  BEGIN
  -- 清除备份日志函数：通过事件定时（默认每天零点运行一次）调用此函数，用来清理（人工导入/自动生成）日志备份表。
  
	CALL proc_imp_log_clear('log_http_msg');  -- 导入日志表所有表名插入临时表tmp_cache_tab中
	CALL proc_bak_log_clear('log_http_msg');  -- 游标查询所有备份表排除掉临时表tmp_cache_tab中的表
	
	CALL proc_imp_log_clear('log_ftp_msg');
	CALL proc_bak_log_clear('log_ftp_msg');
	CALL proc_imp_log_clear('log_sfts_msg');
	CALL proc_bak_log_clear('log_sfts_msg');
	CALL proc_imp_log_clear('log_video_msg');
	CALL proc_bak_log_clear('log_video_msg');
	CALL proc_imp_log_clear('log_gstmedia_msg');
	CALL proc_bak_log_clear('log_gstmedia_msg');
	CALL proc_imp_log_clear('syn_flood_log');
	CALL proc_imp_log_clear('icmp_flood_log');
	CALL proc_imp_log_clear('udp_flood_log');

	-- 双向网闸自动生成的备份日志表与手动导入的日志表，自动清除任务
	CALL proc_bak_log_clear('tw_audit_log');	-- 双向网闸审计日志
	CALL proc_imp_log_clear('tw_audit_log');
	CALL proc_bak_log_clear('tw_oper_log');	-- 双向网闸操作日志
	CALL proc_imp_log_clear('tw_oper_log');
	CALL proc_bak_log_clear('tw_os_log');	-- 双向网闸系统日志
	CALL proc_imp_log_clear('tw_os_log');
	CALL proc_bak_log_clear('tw_serv_log');	-- 双向网闸服务日志
	CALL proc_imp_log_clear('tw_serv_log');
	CALL proc_bak_log_clear('tw_filter_log');	-- 双向网闸非法阻断日志
	CALL proc_imp_log_clear('tw_filter_log');
	
	-- 新双向网闸自动生成的备份日志表与手动导入的日志表，自动清除任务
	CALL proc_bak_log_clear('audit_log');	-- 审计日志
	CALL proc_imp_log_clear('audit_log');
	CALL proc_bak_log_clear('oper_log');	-- 操作日志
	CALL proc_imp_log_clear('oper_log');
	CALL proc_bak_log_clear('os_log');	-- 系统日志
	CALL proc_imp_log_clear('os_log');
	CALL proc_bak_log_clear('filter_log');	-- 非法拦截日志
	CALL proc_imp_log_clear('filter_log');
	CALL proc_bak_log_clear('http_proxy_log');	-- http服务日志
	CALL proc_imp_log_clear('http_proxy_log');
	CALL proc_bak_log_clear('https_proxy_log');	-- https服务日志
	CALL proc_imp_log_clear('https_proxy_log');
	CALL proc_bak_log_clear('smtp_proxy_log');	-- smtp服务日志
	CALL proc_imp_log_clear('smtp_proxy_log');
	CALL proc_bak_log_clear('pop_proxy_log');	-- pop服务日志
	CALL proc_imp_log_clear('pop_proxy_log');
	CALL proc_bak_log_clear('ftp_proxy_log');	-- ftp服务日志
	CALL proc_imp_log_clear('ftp_proxy_log');

	DELETE FROM log_ftp;
	DELETE FROM log_http;
	DELETE FROM log_sfts;
	DELETE FROM log_video;
	DELETE FROM log_gstmedia;
	DELETE FROM log_lbproxy;
  	DELETE FROM log_httpproxy;
	DELETE FROM tw_syslog;	-- 清空双向网闸SYSLOG日志原始报文记录表
	
	DELETE FROM serv_log_template;	-- 清空新双向网闸入股日志记录表

	-- CALL proc_clear_warning_log('log_http_msg');
	-- CALL proc_clear_warning_log('log_ftp_msg');
	-- CALL proc_clear_warning_log('log_sfts_msg');
	-- CALL proc_clear_warning_log('log_video_msg');
	-- CALL proc_clear_warning_log('log_gstmedia_msg');
	-- CALL proc_clear_warning_log('log_lbproxy_msg');
  -- CALL proc_clear_warning_log('log_httpproxy_msg');

END;

