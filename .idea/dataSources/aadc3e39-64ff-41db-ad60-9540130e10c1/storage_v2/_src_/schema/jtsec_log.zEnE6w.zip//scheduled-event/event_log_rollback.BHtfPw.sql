create definer = root@`%` event event_log_rollback
  on schedule
    every '60' SECOND
      starts '2010-11-11 12:39:44'
  on completion preserve
  enable
do
  -- 日志备份回滚事件
-- 用途：用来定时检查日志存储容量情况，根据每个日志表配置的策略，进行日志的备份或回滚操作，默认每小时执行一次。
CALL call_log_secure();

