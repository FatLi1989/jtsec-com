create procedure proc_log_clear(IN t_name varchar(64))
  comment 'java调用此函数完成日志表的删除或是表中数据的删除'
  BEGIN
  -- [v1.0.4] Java调用此函数，完成当前日志表表中数据的清空操作，或删除掉备份日志表的操作。
  -- 采取获取最后一个下划线（_）到后面的字符，然后分析是否为11位，判断是主表
  
	DECLARE last_str_len INT; -- 表名中最后一个分隔符（含）及之后的字符串的长度

  -- SET @t_name_tmp = REVERSE(left(REVERSE(t_name),LOCATE('_',REVERSE(t_name))-1));
	SET last_str_len = LOCATE('_',REVERSE(t_name));

	 SELECT t_name FROM DUAL;
	-- SELECT t_name_tmp FROM DUAL;
	 SELECT last_str_len FROM DUAL;
	-- CALL debug_call("proc_log_clear --> ","t_name_tmp", @t_name_tmp, NULL,NULL,@result);
	
	-- 如果分析处理后的表名最后一个分隔符及之后字符串的长度不为11，证明要清理的表为主表，采取删除主表中数据的策略
	IF(last_str_len != 11) THEN
		SET @sql_tmp = CONCAT("DELETE FROM ",t_name);
		select @sql_tmp from dual;
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
  -- 如果分析处理后的表名与主表名称不相同，证明要清理的表为备份表，采取删除备份表的策略
	ELSE
		SET @sql_tmp = CONCAT("DROP TABLE ",t_name);
		select @sql_tmp from dual;
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	END IF;

END;

