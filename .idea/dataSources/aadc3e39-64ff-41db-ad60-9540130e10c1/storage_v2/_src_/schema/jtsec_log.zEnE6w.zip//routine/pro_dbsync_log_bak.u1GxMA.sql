create procedure pro_dbsync_log_bak(IN t_name varchar(225))
  comment '数据库同步日志备份的实现函数'
  BEGIN
	-- 声明变量
	declare cnt int; -- 当前总数据条数
	declare table_type varchar(225); -- 备份表类型
	declare tab_id_min int; -- 最小id
	declare tab_id_max int; -- 最大id
	declare tab_time_min varchar(225); -- 最小时间
	declare tab_time_max varchar(225); -- 最大时间
	
	-- 获取当前数据条数
	SET @sql_tmp = CONCAT("set @cnt = (select count(*) from ",t_name,");");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 获取最小id值
	SET @sql_tmp = CONCAT("set @tab_id_min = (select min(id) from ",t_name," );");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 获取最大id值
	SET @sql_tmp = CONCAT("set @tab_id_max = (select max(id) from ",t_name," );");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	-- 如果表名为dbsync_extract_log或dbsync_load_log时
	IF(t_name = 'dbsync_extract_log' || t_name = 'dbsync_load_log') THEN
		-- 获取最小时间为min(sync_time)
		SET @sql_tmp = CONCAT("set @tab_time_min = (select min(sync_time) from ",t_name," );");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
		
		-- 获取最大时间为max(sync_time)
		SET @sql_tmp = CONCAT("set @tab_time_max = (select max(sync_time) from ",t_name," );");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	ELSE
		-- 获取最小时间为min(start_time)
		SET @sql_tmp = CONCAT("set @tab_time_min = (select min(start_time) from ",t_name," );");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
		
		-- 获取最大时间为max(start_time)
		SET @sql_tmp = CONCAT("set @tab_time_max = (select max(start_time) from ",t_name," );");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	END IF;
	
	IF(@cnt >= 500000) THEN
		-- 当前数据条数大于等于500000时，修改原日志纪录表dbsync_extract_log的名为dbsync_extract_log_1489631510
		SET @sql_tmp = CONCAT("alter table ",t_name," rename to ",t_name,"_",UNIX_TIMESTAMP());
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
		
		-- 判断表名，如果表名为dbsync_extract_log时，定义类型为table_type=e_log,表名为dbsync_load_log时，类型为table_type=l_log
		-- 表名为dbsync_extract_stats_min时，定义类型为table_type=e_min,表名为dbsync_load_stats_min时，类型为table_type=l_min....
		-- 并创建新的日志表
		IF(t_name = 'dbsync_extract_log') THEN
			SET @table_type = 'e_log';
			SET @sql_tmp = CONCAT("CREATE TABLE dbsync_extract_log (id int(11) NOT NULL AUTO_INCREMENT, storage_time timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP, sync_time timestamp NULL DEFAULT '0000-00-00 00:00:00', serv_name varchar(255) DEFAULT NULL, event varchar(255) DEFAULT NULL, count int(11) DEFAULT NULL, trans_byte int(11) DEFAULT NULL, audit_pass bit(1) DEFAULT NULL, audit_fail_reason varchar(1000) DEFAULT NULL, log_source bit(1) DEFAULT NULL, dev_no varchar(255) DEFAULT NULL, serv_type varchar(255) DEFAULT NULL, db_name varchar(255) DEFAULT NULL, table_name varchar(255) DEFAULT NULL, detail text, dsc varchar(500) DEFAULT NULL, PRIMARY KEY(id), KEY id(id) USING BTREE)ENGINE=MyISAM DEFAULT CHARSET=utf8;");
		ELSEIF(t_name ='dbsync_load_log') THEN
			SET @table_type = 'l_log'; 
			SET @sql_tmp = CONCAT("CREATE TABLE dbsync_load_log (id int(11) NOT NULL AUTO_INCREMENT, storage_time timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP, sync_time timestamp NULL DEFAULT '0000-00-00 00:00:00', serv_name varchar(255) DEFAULT NULL, event varchar(255) DEFAULT NULL, count int(11) DEFAULT NULL, trans_byte int(11) DEFAULT NULL, audit_pass bit(1) DEFAULT NULL, audit_fail_reason varchar(1000) DEFAULT NULL, log_source bit(1) DEFAULT NULL, dev_no varchar(255) DEFAULT NULL, serv_type varchar(255) DEFAULT NULL, db_name varchar(255) DEFAULT NULL, table_name varchar(255) DEFAULT NULL, detail text, dsc varchar(500) DEFAULT NULL, PRIMARY KEY(id), KEY id(id) USING BTREE)ENGINE=MyISAM DEFAULT CHARSET=utf8;");
		ELSEIF(t_name = 'dbsync_extract_stats_min') THEN
			SET @table_type = 'e_min';
			SET @sql_tmp = CONCAT("CREATE TABLE dbsync_extract_stats_min (id int(11) NOT NULL AUTO_INCREMENT, start_time timestamp NULL DEFAULT '0000-00-00 00:00:00', serv_name varchar(255) DEFAULT NULL, db_name varchar(255) DEFAULT NULL, table_name varchar(255) DEFAULT NULL, ins_count int(11) DEFAULT NULL, upd_count int(11) DEFAULT NULL, del_count int(11) DEFAULT NULL, PRIMARY KEY(id), KEY id(id) USING BTREE)ENGINE=MyISAM DEFAULT CHARSET=utf8;");
		ELSEIF(t_name = 'dbsync_load_stats_min') THEN
			SET	@table_type = 'l_min';
			SET @sql_tmp = CONCAT("CREATE TABLE dbsync_load_stats_min (id int(11) NOT NULL AUTO_INCREMENT, start_time timestamp NULL DEFAULT '0000-00-00 00:00:00', serv_name varchar(255) DEFAULT NULL, db_name varchar(255) DEFAULT NULL, table_name varchar(255) DEFAULT NULL, ins_count int(11) DEFAULT NULL, upd_count int(11) DEFAULT NULL, del_count int(11) DEFAULT NULL, PRIMARY KEY(id), KEY id(id) USING BTREE)ENGINE=MyISAM DEFAULT CHARSET=utf8;");
		END IF;
		
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
		-- 将备份记录添加在备份记录表(dbsync_log_bak_record)中
		SET @sql_tmp = CONCAT("insert into dbsync_log_bak_record values(id, '",@table_type,"', '",t_name,"_",UNIX_TIMESTAMP(),"', (select now()), '",@tab_id_min,"', '",@tab_id_max,"', '",@tab_time_min,"', '",@tab_time_max,"');");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	END IF;

END;

