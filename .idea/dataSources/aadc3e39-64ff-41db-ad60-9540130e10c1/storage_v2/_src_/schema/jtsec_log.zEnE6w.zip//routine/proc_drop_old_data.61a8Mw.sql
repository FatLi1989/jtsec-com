create procedure proc_drop_old_data(IN dev_id varchar(100))
  BEGIN

		SET @sql_tmp = CONCAT("DELETE FROM dev_disk_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("DELETE FROM dev_interface_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("DELETE FROM dev_software_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("DELETE FROM dev_progress_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("DELETE FROM report_cpu_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		
		SET @sql_tmp = CONCAT("DELETE FROM report_mem_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

		SET @sql_tmp = CONCAT("DELETE FROM warning_event_info WHERE dev_id='", dev_id, "'");
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

END;

