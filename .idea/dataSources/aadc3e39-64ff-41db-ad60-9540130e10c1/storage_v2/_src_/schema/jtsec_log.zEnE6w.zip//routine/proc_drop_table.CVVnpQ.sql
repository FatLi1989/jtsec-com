create procedure proc_drop_table(IN t_name varchar(100))
  BEGIN
	DECLARE total_tables INT;
	
  DECLARE t_name_var VARCHAR(225);
	DECLARE cur_end INT DEFAULT FALSE;

  
  DECLARE cur CURSOR FOR select TABLE_NAME from information_schema.tables where table_name like CONCAT(t_name,'%') ORDER BY TABLE_NAME DESC ;
  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_end = TRUE;

	 
	OPEN cur;
	
	read_loop: LOOP
		
		FETCH cur INTO t_name_var;
		
		IF (cur_end)THEN
			LEAVE read_loop;
		END IF;
		
		SET @sql_tmp = CONCAT("DROP TABLE ",t_name_var);
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;

	END LOOP;
	
	CLOSE cur;


	
	
END;

