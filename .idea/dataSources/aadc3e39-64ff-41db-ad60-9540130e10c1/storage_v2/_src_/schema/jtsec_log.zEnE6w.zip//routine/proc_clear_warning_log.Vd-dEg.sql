create procedure proc_clear_warning_log(IN t_name varchar(20))
  BEGIN
  -- 该存储过程的作用为：自动清理指定日志表，在触发临界阈值、达到阈值、发生回滚等日志安全保障行为时，产生的警告信息日志。
  -- 这里预设规则为，每个日志表相关的记录超过500条则进行一次清理，只保留500条。
  -- 系统通过定时事件event_clear_baklog（清除备份日志），调用call_log_clear（备份日志清除函数），在该函数中会对指定表执行该存储过程。

	DECLARE cnt INT DEFAULT 0;
  
  -- 统计指定表在日志存储告警记录表中数据的条数
	SET @sql_tmp = CONCAT("SET @cnt = (select count(*) from log_warning where table_name='", t_name,"')");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
  -- 如果数量超过500条
	IF(@cnt > 500) THEN
		SELECT @cnt FROM DUAL;
    -- 则执行记录清理操作，并且每类日志表的相关警告信息记录只保留500条。
		SET @sql_tmp = CONCAT("DELETE FROM log_warning WHERE table_name='",t_name,"' ORDER BY ReceivedAt ASC LIMIT ", @cnt - 500);
		PREPARE pre_sql FROM @sql_tmp;
		EXECUTE pre_sql;
	END IF;
END;

