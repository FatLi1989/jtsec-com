create procedure debug_call(IN col1 text, IN col2 text, IN col3 text, IN col4 text, IN col5 text, OUT result text)
  comment '调试存储过程时的辅助函数，可以通过它进行关键值的监控'
  BEGIN
  -- 调试存储过程时的辅助函数，可以通过它进行关键值的监控，并将传入的参数存储到debug_tab表中，便于查看调试结果
  -- 暂时定义了5个text类型的输入函数，和1个text类型的输出函数

	SET @debug_tmp =  CONCAT("insert INTO `debug_tab` (`col1`, `col2`, `col3`, `col4`, `col5`) values ('", IFNULL(col1,''), "','", IFNULL(col2,''), "','", IFNULL(col3,''), "','", IFNULL(col4,''), "','", IFNULL(col5,'') ,"');");
	PREPARE debug_sql FROM @debug_tmp;
	EXECUTE debug_sql;
	SET result = @debug_tmp;
END;

