create definer = root@`%` event event_log_sec
  on schedule
    every '60' SECOND
      starts '2010-11-11 12:39:46'
  enable
do
  CALL proc_auto_rollback_bak_table(0);

