create procedure proc_imp_log_clear(IN t_name varchar(255))
  comment '清理导入的日志备份表'
  BEGIN
	-- 此存储过程为正在使用版。（by lioncode at 2017-10-28 18:42）
	-- 该存储过程的作用为：清理给定日志表对应的人工导入的备份表，根据日志策略（导入备份表数量及最大存储天数）判断哪些人工导入系统的日志备份表应该被清理，并执行相应操作。
  -- 系统通过定时事件event_clear_baklog（清除备份日志），调用call_log_clear（备份日志清除函数），在该函数中会对指定表执行该存储过程。

	DECLARE done INT DEFAULT 0;  -- 用于判断是否结束循环
	DECLARE t_id INT; -- 字段id值
	DECLARE imp_tabs VARCHAR(225);  -- 导入备份表集合
	DECLARE imp_days INT DEFAULT 0;  -- 备份表已导入天数
	
	DECLARE imp_tab_count INT DEFAULT 0;	-- 导入表数量计数器
	DECLARE tab_number INT DEFAULT 0;
	DECLARE imp_tab_max_count INT;  --  导入表最大数量
	DECLARE store_time INT DEFAULT 0;	  -- 导入表存储时间
	
	DECLARE cur CURSOR FOR SELECT id, bak_tab_list, TIMESTAMPDIFF(DAY, oper_time, NOW()) FROM log_bak_record WHERE bak_file LIKE CONCAT(t_name,"_%") AND oper_type = '1' AND status = '0' GROUP BY bak_tab_list ORDER BY oper_time DESC;
	
	-- 定义 设置循环结束标识done值怎么改变的逻辑
	DECLARE continue handler for not FOUND set done = 1; -- done = true;亦可

	-- 查询策略配置中设置的：导入表最大数量
	SET @sql_tmp = CONCAT("SET @imp_tab_max_count = (select imp_tab_max from jtsec_com.logconfig where table_name = '",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;

	-- 查询策略配置中设置的：导入表最大存储时间
	SET @sql_tmp = CONCAT("SET @store_time = (select imp_tab_store_time from jtsec_com.logconfig where table_name = '",t_name,"');");
	PREPARE pre_sql FROM @sql_tmp;
	EXECUTE pre_sql;
	
	
	DELETE FROM tmp_cache_tab;
	SET @imp_tab_count = 0;
	
	OPEN cur;  -- 打开游标
	REPEAT
		-- 可以fetch多列（假设结果集S_S的记录不是单列的话）
		fetch cur into t_id, imp_tabs, imp_days;
		-- 数值为非0，MySQL认为是true
-- 		CALL debug_call("游标开始", NULL, NULL, NULL, NULL, @result);
		IF not done THEN
-- 			CALL debug_call("游标进入", NULL, NULL, NULL, NULL, @result);
			SET @tabs_len = LENGTH(imp_tabs) > 0;  -- 判断imp_tabs中是否有数据 TRUE为有数据  FALSE为没有数据
			-- <------------------------- START 调试日志 -------------------------->
-- 				CALL debug_call("循环开始",NULL,NULL,NULL,NULL,@result);
-- 				SET @sql_tmp = CONCAT("CALL debug_call('游标开始一次遍历！ ',' 已导入天数--> ", IFNULL(imp_days,"空"),"','t_id --> ", IFNULL(t_id,"空"),"','导入的所有表名 --> ", IFNULL(imp_tabs,"空"),"','表名个数 --> ",IFNULL(@length,"空"),"',", "@result",");");
-- 				PREPARE pre_sql FROM @sql_tmp;
-- 				EXECUTE pre_sql;
-- 				CALL debug_call("将判断文件是否过期",if(( imp_days >= @store_time ),"过期","未过期"),IF(@tabs_len,"有备份表名","没有备份表名"),imp_days,@store_time,@result);
-- 				-- <------------------------- END   调试日志 -------------------------->
			-- 导入备份表存储时间 大于 最大存储时间，对其执行删除
			IF @tabs_len AND ( imp_days >= @store_time ) THEN
				-- <------------------------- START 调试日志 -------------------------->
-- 				CALL debug_call("表过期执行删除 表===>", imp_tabs, NULL, NULL, NULL,@result);
				-- <------------------------- END   调试日志 -------------------------->	
				SET @sql_tmp = CONCAT("DROP TABLE IF EXISTS ", imp_tabs);
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;
				-- <------------------------- START 调试日志 -------------------------->
-- 				CALL debug_call("WHILE循环 删除表 --> ",NULL,NULL,@sql_tmp,NULL,@result);
				-- <------------------------- END   调试日志 -------------------------->	
				SET @sql_tmp = CONCAT("UPDATE log_bak_record SET status = '1', file_del_time = NOW() WHERE id = ",t_id);
				PREPARE pre_sql FROM @sql_tmp;
				EXECUTE pre_sql;

			ELSEIF(@tabs_len) THEN			
				SET @imp_tab_count = @imp_tab_count + 1;
-- 				CALL debug_call("导入表未过期数量判断 1.表计数 2.最大数 3.导入表名", IF((@imp_tab_count <= @imp_tab_max_count),"未超出","超出"), @imp_tab_count, @imp_tab_max_count, imp_tabs,@result);
				IF( @imp_tab_count <= @imp_tab_max_count ) THEN
					
					SET @sql_tmp = CONCAT("SET @tab_number = (SELECT count(*) FROM tmp_cache_tab WHERE col1 = '", imp_tabs, "')");
					PREPARE pre_sql FROM @sql_tmp;
					EXECUTE pre_sql;
-- 						CALL debug_call("查询表是否已存在tmp_cache_tab表1.临时表中是否存在0.不1.存在",@tab_number, @imp_tab_count ,imp_days,NULL,@result);
					IF(@tab_number = 0)THEN
						INSERT INTO tmp_cache_tab (col1) VALUES(imp_tabs);
-- 							CALL debug_call("表不存在进行插入", NULL, NULL , NULL, NULL,@result);
					ELSE
						SET @imp_tab_count = @imp_tab_count - 1;
-- 							CALL debug_call("表存在", NULL, NULL , NULL, NULL,@result);
					END IF;

				ELSE  -- 超过限定数量的表
-- 					CALL debug_call("导入表超出数量删除 表-->", imp_tabs, NULL, NULL, NULL,@result);
					SET @sql_tmp = CONCAT("DROP TABLE IF EXISTS ", imp_tabs);
					PREPARE pre_sql FROM @sql_tmp;
					EXECUTE pre_sql;
					-- <------------------------- START 调试日志 -------------------------->
-- 					CALL debug_call("WHILE循环 删除表 --> ",NULL,NULL,@sql_tmp,NULL,@result);
					-- <------------------------- END   调试日志 -------------------------->	

					SET @sql_tmp = CONCAT("UPDATE log_bak_record SET status = '1', file_del_time = NOW() WHERE id = ",t_id);
					PREPARE pre_sql FROM @sql_tmp;
					EXECUTE pre_sql;
				
				END IF;
			END IF;					
				-- <------------------------- START 调试日志 -------------------------->
-- 			CALL debug_call(NULL,NULL,NULL,NULL,NULL,@result);
				-- <------------------------- END   调试日志 -------------------------->
		END IF;
	UNTIL done END REPEAT;
	CLOSE cur;  -- 关闭游标
END;

